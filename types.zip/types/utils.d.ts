export function encodeFileB64(path: any): string;
export function urlResolver(environment?: string): any;
